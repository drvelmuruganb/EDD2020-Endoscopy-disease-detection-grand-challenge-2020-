#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov  7 00:30:44 2018

@author: sumanthnandamuri
"""
import numpy as np
import torch
from sklearn.metrics import confusion_matrix
from torch.utils.data import DataLoader, TensorDataset
from scipy.ndimage.morphology import distance_transform_edt

# def dice_coefficient(pred, target):
#     smooth = 1e-15
#     num = pred.size()[0]
#     m1 = pred.view(num, -1).float()
#     m2 = target.view(num, -1).float()
#     intersection = (m1*m2).sum(1)
#     union = (m1 + m2).sum(1) + smooth - intersection
#     score = intersection/union
#     return score.mean()

# def dice_coefficient(pred, target):
#     smooth = 1e-15
#     num = pred.size()[0]
#     score = np.zeros(pred.shape[1])
#     for classNum in range(pred.shape[1]):
#         m1 = pred[:,classNum].contiguous().view(num,-1).float()
#         m2 = target[:,classNum].contiguous().view(num,-1).float()        
#         intersection = (m1*m2).sum(1)
#         union = (m1 + m2).sum(1) + smooth - intersection   
#         # print(intersection/union)    
#         score[classNum] = (intersection/union).mean()
#     # print(score)
#     return score

# Dice Coefficient
def dice_coefficient(pred, target):
    score = np.zeros(pred.shape[1])    
    for classNum in range(pred.shape[1]):        
        c = confusion_matrix(target[:,classNum].long().contiguous().view(-1).cpu().numpy(), pred[:,classNum].contiguous().long().view(-1).cpu().numpy(),labels=[0,1])
        TP = np.diag(c)        
        FP = c.sum(axis=0) - np.diag(c)  
        FN = c.sum(axis=1) - np.diag(c)
        TN = c.sum() - (FP + FN + TP)        
        # print((2*TP)/(2*TP + FP + FN ))
        score[classNum] = (2*TP[1]+1e-10)/(2*TP[1] + FP[1] + FN[1]+1e-10 )
    return score

def get_weights(labels_batch):
    weights = np.array([])
    labels_batch_numpy = labels_batch.numpy()
    n = labels_batch_numpy.shape[0]
    labels_batch_numpy = labels_batch_numpy.astype('uint8')
    for i in range(n):
        label = labels_batch_numpy[i][0]
        trnsf = distance_transform_edt(label)
        trnsf = ((np.abs((trnsf.max() - trnsf))/trnsf.max())*(trnsf>=1.)+1)
        trnsf = trnsf.flatten()
        weights = np.concatenate((weights, trnsf))
    weights = torch.from_numpy(weights).float()
    return weights

def make_loader(twisted_labels, fake_labels, one, zero, bs = 24):
    images = torch.cat([twisted_labels, fake_labels], 0)
    labels = torch.cat([one, zero], 0)
    discriminatorDataset = TensorDataset(images, labels)
    discriminatorDataLoader = DataLoader(discriminatorDataset, batch_size = bs, shuffle = True, num_workers = 4, pin_memory = True)
    return discriminatorDataLoader