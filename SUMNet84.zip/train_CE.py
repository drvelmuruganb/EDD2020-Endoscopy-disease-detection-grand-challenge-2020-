#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov  7 00:27:04 2018

@author: sumanthnandamuri
"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch import optim
import tqdm
import time
import gc

from SUMNet import SUMNet
from utils import dice_coefficient_ce, make_loader
from edd_loader import eddLoader
from torch.utils import data
import torch.nn.functional as F

# from aug_utils import *
import augmentation as aug
import sys
import os
from torch.optim.lr_scheduler import ReduceLROnPlateau



data_path = '/home/histosr/Desktop/Media/EDD2020_release-I_2020-01-15_v2_s3/EDD2020_release-I_2020-01-15/'


data_aug = aug.Compose([aug.RandomRotate(10), aug.RandomHorizontallyFlip(0.5),aug.RandomHorizontallyFlip(0.5),\
    aug.AdjustGamma(1.5),aug.AdjustSaturation(0.5),aug.AdjustHue(0.5),aug.AdjustBrightness(0.5),aug.AdjustContrast(0.5)])
# data_aug = aug.Compose([aug.AdjustGamma(1.5),aug.AdjustSaturation(0.5),aug.AdjustHue(0.5),aug.AdjustBrightness(0.5),\
    # aug.AdjustContrast(0.5), aug.RandomHorizontallyFlip(0.5),aug.RandomHorizontallyFlip(0.5)])
# data_aug = None

savePath = 'Results/SumNet_with_augs_CELoss_withWt_withLRS_512/'
if not os.path.isdir(savePath):
    os.makedirs(savePath)



trainLoader = eddLoader(
        data_path,
        is_transform=True,
        split='train',
        img_size=(512,512),
        augmentations=data_aug,
    )
trainDataLoader = data.DataLoader(
       trainLoader,
        batch_size=4,
        num_workers=4,
        shuffle=True,
    )
v_loader = eddLoader(
        data_path,
        is_transform=True,
        split='val',
        img_size=(512,512),
        augmentations=None,
    )
validDataLoader = data.DataLoader(
        v_loader, batch_size=4, num_workers=4
    )

net = SUMNet()

use_gpu = torch.cuda.is_available()
if use_gpu:
    net = net.cuda()
  
optimizer = optim.Adam(net.parameters(), lr = 1e-4)
scheduler = ReduceLROnPlateau(optimizer, 'min',verbose=True)
criterion = nn.CrossEntropyLoss(weight=torch.Tensor([2,4,5,7,3]).cuda())


def train(trainDataLoader, validDataLoader, net, optimizer, criterion, use_gpu):
    epochs = 400
    trainLoss = []
    validLoss = []
    trainDiceCoeff = []
    validDiceCoeff = []
    start = time.time()
    bestValidDice = np.zeros(5)
    
    for epoch in range(epochs):
        epochStart = time.time()
        trainRunningLoss = 0
        validRunningLoss = 0
        trainBatches = 0
        validBatches = 0
        trainDice = np.zeros(5)
        validDice = np.zeros(5)
        
        net.train(True)
        for data in tqdm.tqdm(trainDataLoader):
            inputs, labels1 = data
            labels1 = labels1/255.0

            labels = torch.argmax(labels1,dim=1)
            
            if use_gpu:
                inputs = inputs.cuda()
                labels = labels.cuda()

            probs = net(inputs)     
            
            loss = criterion(probs,labels)
            
            preds = torch.argmax(F.softmax(probs,dim=1),dim=1)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            trainRunningLoss += loss.item()
            
            trainDice += dice_coefficient_ce(preds,labels)


            trainBatches += 1
            
            # if trainBatches == 4:
            #     break
        trainLoss.append(trainRunningLoss/trainBatches)

        trainDiceCoeff.append(trainDice/trainBatches)
        
        net.train(False)
        for data in tqdm.tqdm(validDataLoader):
            inputs, labels1 = data
            labels1 = labels1/255.0

            labels = torch.argmax(labels1,dim=1)
            
            if use_gpu:
                inputs = inputs.cuda()
                labels = labels.cuda()
            
            probs = net(inputs)
            
            loss = criterion(probs,labels)

            
            preds = torch.argmax(probs,dim=1)

            validDice += dice_coefficient_ce(preds,labels)

            validRunningLoss += loss.item()
            validBatches += 1
            # if validBatches == 4:
            #     break
        scheduler.step(validRunningLoss/validBatches)
        validLoss.append(validRunningLoss/validBatches)
        validDiceCoeff.append(validDice/validBatches)
        if validDice[0] > bestValidDice[0]:
            bestValidDice[0] = validDice[0]
            torch.save(net.state_dict(), savePath+'SUMNet_class0_best.pt')
        if validDice[1] > bestValidDice[1]:
            bestValidDice[1] = validDice[1]
            torch.save(net.state_dict(), savePath+'SUMNet_class1_best.pt')
        if validDice[2] > bestValidDice[2]:
            bestValidDice[2] = validDice[2]
            torch.save(net.state_dict(), savePath+'SUMNet_class2_best.pt')
        if validDice[3] > bestValidDice[3]:
            bestValidDice[3] = validDice[3]
            torch.save(net.state_dict(), savePath+'SUMNet_class3_best.pt')
        if validDice[4] > bestValidDice[4]:
            bestValidDice[4] = validDice[4]
            torch.save(net.state_dict(), savePath+'SUMNet_class4_best.pt')

        epochEnd = time.time()-epochStart
        print('Epoch: {:.0f}/{:.0f} | Train Loss: {:.3f} | Valid Loss: {:.3f} |'\
              .format(epoch+1, epochs, trainRunningLoss/trainBatches, validRunningLoss/validBatches))
        print('Train Dice : {:.3f},{:.3f},{:.3f},{:.3f},{:.3f} '.format(trainDice[0]/trainBatches,trainDice[1]/trainBatches,trainDice[2]/trainBatches,trainDice[3]/trainBatches,trainDice[4]/trainBatches))
        print('Valid Dice : {:.3f},{:.3f},{:.3f},{:.3f},{:.3f} '.format(validDice[0]/validBatches,validDice[1]/validBatches,validDice[2]/validBatches,validDice[3]/validBatches,validDice[4]/validBatches))
        print('Time: {:.0f}m {:.0f}s'.format(epochEnd//60,epochEnd%60))
        # break
    end = time.time()-start
    print('Training completed in {:.0f}m {:.0f}s'.format(end//60,end%60))

    torch.save(trainLoss,savePath+'trainLoss.pt')
    torch.save(validLoss,savePath+'validLoss.pt')
    torch.save(trainDiceCoeff,savePath+'trainDiceCoeff.pt')
    torch.save(validDiceCoeff,savePath+'validDiceCoeff.pt')
    # trainLoss = np.array(trainLoss)
    # validLoss = np.array(validLoss)
    # trainDiceCoeff = np.array(trainDiceCoeff)
    # validDiceCoeff = np.array(validDiceCoeff)
    # DF = pd.DataFrame({'Train Loss': trainLoss, 'Valid Loss': validLoss, 'Train Dice': trainDiceCoeff, 'Valid Dice': validDiceCoeff})
    # return DF

train(trainDataLoader, validDataLoader, net, optimizer, criterion, use_gpu)
# DF.to_csv('SUMNet.csv')

