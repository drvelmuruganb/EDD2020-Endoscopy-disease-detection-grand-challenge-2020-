#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov  7 00:27:04 2018

@author: sumanthnandamuri
"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch import optim
import torch.nn.functional as F
import tqdm
import time
import gc

from SUMNet_sig import SUMNet
from utils import dice_coefficient, make_loader
from edd_loader import eddLoader
from torch.utils import data
from torchvision import transforms

# from aug_utils import *
import augmentation as aug
import sys
import os
from PIL import Image

from scipy import ndimage

# import scipy.misc as sm

import tifffile as tiff


savePath = 'Results/SumNet_with_augs/'
M = 512 #image size
outpath = savePath
net = SUMNet()
# checkpoint = torch.load(weight_path)
net.load_state_dict(torch.load(savePath+'SUMNet_class0_best.pt'))#saved weight path
net.eval()
use_gpu = torch.cuda.is_available()
if use_gpu:
    net = net.cuda()


tf = transforms.Compose(
            [
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
            ]
        )

net.train(False)

loadPath = '/home/histosr/Desktop/Media/EDD_evaluation_test-Final/'
test_list = os.listdir(loadPath)

img_folder = savePath+'EDD_evaluation_test-Final_bestPolyp_thresh0.5/'
if not os.path.isdir(img_folder):
    os.makedirs(img_folder)

def CC(Map):
    label_img, cc_num = ndimage.label(Map)
    CC = ndimage.find_objects(label_img)
    cc_areas = ndimage.sum(Map, label_img, range(cc_num+1))
    area_mask = (cc_areas < 100000)
    label_img[area_mask[label_img]] = 0
    return label_img, CC


for test_img_name in tqdm.tqdm(test_list):
    test_img = Image.open(loadPath+test_img_name)
    img_orig_size = test_img.size
    test_img = test_img.resize((M,M))

    test_inp = tf(test_img)

        
    if use_gpu:
        test_inp = test_inp.cuda()


    ############################### For network with sigmoid ################
    probs = net(test_inp.unsqueeze(0)).squeeze(0).cpu()
    preds = (probs > 0.5).float()
    preds[preds>0] = 255
    pred_np = np.asarray(preds.numpy(),dtype=np.uint8)

    ################### For network without sigmoid ########################
    # probs = F.softmax(net(test_inp.unsqueeze(0)),dim=1).cpu()
    # preds1 = torch.argmax(probs,dim=1).squeeze(0).numpy()
    # preds = np.zeros((5,M,M))
    # for classNum in range(5):
    #     idx = np.where(preds1==classNum)
    #     preds[classNum,idx[0],idx[1]] = 255     
    # pred_np = np.asarray(preds,dtype=np.uint8)
    ##########################################################################

    ####### Resize to original size #################
    pred_data = np.zeros((5,img_orig_size[1],img_orig_size[0]))
    for classNum in range(5):
        pred_data[classNum] = np.array(Image.fromarray(pred_np[classNum]).resize(img_orig_size))

    tiff.imwrite(img_folder+test_img_name[:-3]+'tif',pred_np)

   
    # break

           